package com.example.go4lunch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.go4lunch.base.BaseActivity;

public class MainActivity extends BaseActivity {

    @Override
    public int getFragmentLayout() {
        return R.layout.activity_main;
    }


}
